package br.padroes.decorator;

public abstract class Coquetel {
	String nome;
	double preco;

	public String getNome() {
		return nome;
	}

	public double getPreco() {
		return preco;
	}
}
