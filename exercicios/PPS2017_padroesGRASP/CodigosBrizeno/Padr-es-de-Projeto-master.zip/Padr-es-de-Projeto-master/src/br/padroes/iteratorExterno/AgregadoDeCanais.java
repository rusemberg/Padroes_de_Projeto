package br.padroes.iteratorExterno;

public interface AgregadoDeCanais {
	IteradorInterface criarIterator();
}