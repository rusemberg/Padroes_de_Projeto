package br.padroes.flyweight;

public abstract class SpriteFlyweight {
	public abstract void desenharImagem(Ponto ponto);
}
