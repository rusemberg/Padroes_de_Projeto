package br.padroes.chain;

public enum IDBancos {
	bancoA, bancoB, bancoC, bancoD 
}
