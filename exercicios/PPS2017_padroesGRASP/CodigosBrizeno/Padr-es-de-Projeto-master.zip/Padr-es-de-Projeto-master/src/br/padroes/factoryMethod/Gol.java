package br.padroes.factoryMethod;

public class Gol implements Carro {

	@Override
	public void exibirInfo() {
		System.out.println("Modelo: Gol\nFabricante: Volkswagen");
	}

}
