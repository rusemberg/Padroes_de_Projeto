package br.padroes.visitor;

public interface ArvoreVisitor {

	void visitar(No no);

}
