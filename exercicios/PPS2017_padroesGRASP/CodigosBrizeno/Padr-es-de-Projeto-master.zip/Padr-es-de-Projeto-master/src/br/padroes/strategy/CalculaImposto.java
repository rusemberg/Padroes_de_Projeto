package br.padroes.strategy;

interface CalculaImposto {
	double calculaSalarioComImposto(Funcionario umFuncionario);
}
