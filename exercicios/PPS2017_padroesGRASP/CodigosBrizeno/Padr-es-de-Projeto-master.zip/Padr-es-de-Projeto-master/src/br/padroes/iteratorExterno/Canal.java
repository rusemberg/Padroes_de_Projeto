package br.padroes.iteratorExterno;

public class Canal {
	public String nome;

	public Canal(String nome) {
		this.nome = nome;
	}
}
