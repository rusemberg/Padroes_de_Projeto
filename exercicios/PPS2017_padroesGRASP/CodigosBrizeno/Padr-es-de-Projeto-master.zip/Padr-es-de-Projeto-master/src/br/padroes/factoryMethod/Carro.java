package br.padroes.factoryMethod;

public interface Carro {
	void exibirInfo();
}
