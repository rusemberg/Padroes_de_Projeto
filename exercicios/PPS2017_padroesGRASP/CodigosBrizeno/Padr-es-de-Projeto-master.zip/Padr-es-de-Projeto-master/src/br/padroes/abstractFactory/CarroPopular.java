package br.padroes.abstractFactory;

public interface CarroPopular {
	void exibirInfoPopular();
}
