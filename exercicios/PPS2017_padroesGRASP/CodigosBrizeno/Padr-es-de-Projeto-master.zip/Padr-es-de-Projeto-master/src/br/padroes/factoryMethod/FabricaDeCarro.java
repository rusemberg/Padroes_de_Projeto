package br.padroes.factoryMethod;

public interface FabricaDeCarro {
	Carro criarCarro();
}
