package br.padroes.command;

public interface PagamentoCommand {
	void processarCompra(Compra compra);
}
