package br.padroes.composite.seguro;

public class ArquivoVideo extends ArquivoComponent {
	public ArquivoVideo(String nomeDoArquivo) {
		this.nomeDoArquivo = nomeDoArquivo;
	}
}
