package br.padroes.composite.transparente;

public class ArquivoVideo extends ArquivoComponent {

	public ArquivoVideo(String nomeDoArquivo) {
		this.nomeDoArquivo = nomeDoArquivo;
	}
}
