package br.padroes.templateMethod;

public enum ModoDeReproducao {
	porNome, porAutor, porAno, porEstrela
}
