package br.padroes.decorator;

public class Cachaca extends Coquetel {
	public Cachaca() {
		nome = "Cacha�a";
		preco = 1.5;
	}
}
