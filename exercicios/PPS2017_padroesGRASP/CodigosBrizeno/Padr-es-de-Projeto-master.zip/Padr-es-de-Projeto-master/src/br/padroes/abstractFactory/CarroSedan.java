package br.padroes.abstractFactory;

public interface CarroSedan {
	void exibirInfoSedan();
}
